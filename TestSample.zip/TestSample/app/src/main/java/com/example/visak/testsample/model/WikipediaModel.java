package com.example.visak.testsample.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class WikipediaModel {

    @SerializedName("query")
    private PersonModel query;

    public PersonModel getQuery() {
        return query;
    }

    public void setQuery(PersonModel query) {
        this.query = query;
    }
}
