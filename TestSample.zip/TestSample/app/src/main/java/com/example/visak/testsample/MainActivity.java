package com.example.visak.testsample;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.visak.testsample.adapter.CustomAdapter;
import com.example.visak.testsample.model.WikipediaModel;
import com.example.visak.testsample.network.GetDataService;
import com.example.visak.testsample.network.RetrofitClientInstance;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private CustomAdapter adapter;
    private RecyclerView recyclerView;
    private ProgressDialog progressDoalog;
    private EditText mSerach;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressDoalog = new ProgressDialog(MainActivity.this);
        progressDoalog.setMessage("Loading....");


        final GetDataService service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);

        mSerach = findViewById(R.id.et_search);
        mSerach.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int count, int i2) {
                progressDoalog.show();
                /*Create handle for the RetrofitInstance interface*/
                Call<WikipediaModel> call = service.getWikiPedia(charSequence.toString());
                call.enqueue(new Callback<WikipediaModel>() {
                    @Override
                    public void onResponse(Call<WikipediaModel> call, Response<WikipediaModel> response) {
                        progressDoalog.dismiss();
                        generateDataList(response.body());
                    }

                    @Override
                    public void onFailure(Call<WikipediaModel> call, Throwable t) {
                        progressDoalog.dismiss();
                        Toast.makeText(MainActivity.this, "Something went wrong...Please try later!", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


    }

    /*Method to generate List of data using RecyclerView with custom adapter*/
    private void generateDataList(final WikipediaModel photoList) {
        recyclerView = findViewById(R.id.recycler_view);
        adapter = new CustomAdapter(this, photoList.getQuery().getPages());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
    }
}
