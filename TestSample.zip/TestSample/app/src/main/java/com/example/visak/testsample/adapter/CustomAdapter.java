package com.example.visak.testsample.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.visak.testsample.MainActivity;
import com.example.visak.testsample.R;
import com.example.visak.testsample.WebPageActivity;
import com.example.visak.testsample.model.PagesModel;
import com.example.visak.testsample.model.WikipediaModel;
import com.jakewharton.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {

    private List<PagesModel> dataList;
    private Context context;

    public CustomAdapter(Context context, List<PagesModel> dataList){
        this.context = context;
        this.dataList = dataList;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        public final View mView;

        TextView txtTitle;
        private ImageView coverImage;
        private ConstraintLayout main;

        CustomViewHolder(View itemView) {
            super(itemView);
            mView = itemView;

            main = mView.findViewById(R.id.cl_main);
            txtTitle = mView.findViewById(R.id.title);
            coverImage = mView.findViewById(R.id.cover_image);
            main.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, WebPageActivity.class);
                    intent.putExtra ( "Title", dataList.get(getAdapterPosition()).getTitle());
                    context.startActivity(intent);
                }
            });
        }
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.custom_row, parent, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        holder.txtTitle.setText(dataList.get(position).getTitle());

        if(dataList.get(position).getThumbnail() != null) {
            Picasso.Builder builder = new Picasso.Builder(context);
            builder.downloader(new OkHttp3Downloader(context));
            builder.build().load(dataList.get(position).getThumbnail().getSource())
                    .placeholder((R.drawable.ic_launcher_background))
                    .error(R.drawable.ic_launcher_background)
                    .into(holder.coverImage);
        }

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}