package com.example.visak.testsample.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PersonModel {

    @SerializedName("pages")
    private List<PagesModel> pages;

    public List<PagesModel> getPages() {
        return pages;
    }

    public void setPages(List<PagesModel> pages) {
        this.pages = pages;
    }
}
