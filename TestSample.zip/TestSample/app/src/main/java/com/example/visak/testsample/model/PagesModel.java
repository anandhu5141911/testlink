package com.example.visak.testsample.model;

import com.google.gson.annotations.SerializedName;

public class PagesModel {

    @SerializedName("title")
    private String title;

    @SerializedName("index")
    private int index;

    @SerializedName("thumbnail")
    private ThumbnailModel thumbnail;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public ThumbnailModel getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(ThumbnailModel thumbnail) {
        this.thumbnail = thumbnail;
    }
}
