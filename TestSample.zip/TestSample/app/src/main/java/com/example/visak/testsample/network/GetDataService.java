package com.example.visak.testsample.network;

import com.example.visak.testsample.model.WikipediaModel;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface GetDataService {

    @GET("api.php?action=query&format=json&prop=pageimages%7Cpageterms&generator=prefixsearch&redirects=1&formatversion=2&piprop=thumbnail&pithumbsize=50&pilimit=10&wbptterms=description&gpslimit=100")
    Call<WikipediaModel> getWikiPedia(@Query("gpssearch") String search);
}